# My Website

Homework 2 - a personal website built with HTML and CSS.

Live site: https://tamersarsor123.github.io/web-home-works/homework2/
